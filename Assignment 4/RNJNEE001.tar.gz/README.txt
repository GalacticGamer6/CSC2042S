Archive includes:
Report.pdf
A4.ipynb

Required libraries:

- matplotlib
- torch
- pandas
- torchvision
- itertools
- sklearn