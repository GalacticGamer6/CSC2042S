Standard .ipynb file
install pytorch, sklearn, numpy and pandas
Or just open in anaconda for hassle free experience
